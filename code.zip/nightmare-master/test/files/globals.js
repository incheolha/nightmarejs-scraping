/** @type {Comment} [description] */
globalNumber = 7;
